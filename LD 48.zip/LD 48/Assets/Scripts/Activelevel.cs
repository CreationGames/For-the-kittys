﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Activelevel : MonoBehaviour
{
   void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.name.Equals ("Player"))
        {
            LoadCurrenetLevel();
        }
        
    }

    public void LoadCurrenetLevel()
    {
         SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
