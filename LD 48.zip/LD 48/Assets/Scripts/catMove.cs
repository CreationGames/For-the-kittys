﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class catMove : MonoBehaviour
{
    public Rigidbody rb;

    // Update is called once per frame
    void Update()
    {
        rb.AddForce(Vector3.back * 1 * 5);
    }
}
