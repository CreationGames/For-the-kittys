﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class fallBlock : MonoBehaviour
{
    public Rigidbody rb;

     void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.name.Equals ("Player") )
        {
            Invoke("Thefall",1f);
        }                  
    }
    void Thefall()
    {
         rb.AddForce(Vector3.down * 100 * 100);
    }

}
