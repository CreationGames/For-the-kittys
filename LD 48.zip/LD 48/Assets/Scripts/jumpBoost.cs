﻿
using UnityEngine;

public class jumpBoost : MonoBehaviour
{
    public Jump jump;
    void start()
    {
        jump = FindObjectOfType<Jump>();

    }

       void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.name.Equals ("Player"))
        {
            jump.jumpStrength = 5;
            Destroy(gameObject);
        }        
    }

}
